export default {
  'is-success': 'is-success',
  'is-warning': 'is-warning',
  'is-error': 'is-error',
};
